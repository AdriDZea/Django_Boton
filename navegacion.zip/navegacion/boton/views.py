from django.shortcuts import render

def boton(request):
    return render(request, 'paginaboton.html', {})

def get(request):
    return render(request, 'segundo.html', {})
