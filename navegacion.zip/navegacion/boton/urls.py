from django.urls import path
from boton import views

urlpatterns = [
    path('', views.boton, name='paginaboton'),
    path('segundo', views.get, name='segundo'),
]
