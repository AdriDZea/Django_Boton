from django.apps import AppConfig


class BotonConfig(AppConfig):
    name = 'boton'
